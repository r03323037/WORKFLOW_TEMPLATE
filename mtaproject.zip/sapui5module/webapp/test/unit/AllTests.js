sap.ui.define([
	"ns/sapui5module/test/unit/controller/View1.controller"
], function () {
	"use strict";
});