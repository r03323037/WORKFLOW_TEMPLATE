sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"ns/sapui5module/model/models"
], function (UIComponent, Device, models) {
	"use strict";

	return UIComponent.extend("ns.sapui5module.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// enable routing
			this.getRouter().initialize();

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
			
			
			//Get the Task Instance ID
			var startupParameters = this.getComponentData().startupParameters;
			var taskModel = startupParameters.taskModel;
			var taskId = taskModel.getData().InstanceID;
			
			//Read Task Context Data
			var contextModel = new sap.ui.model.json.JSONModel("/<app id>/bpmworkflowruntime/v1/task-instances/" + taskId + "/context");
			contextModel.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
			this.setModel(contextModel);
			
			
		}
	});
});